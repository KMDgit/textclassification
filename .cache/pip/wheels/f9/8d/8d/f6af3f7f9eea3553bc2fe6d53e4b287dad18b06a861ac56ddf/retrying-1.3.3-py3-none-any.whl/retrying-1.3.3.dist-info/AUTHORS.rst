Retrying is written and maintained by Ray Holder and
various contributors:

Development Lead
````````````````

- Ray Holder


Patches and Suggestions
```````````````````````

- Anthony McClosky
- Jason Dunkelberger
- Justin Turner Arthur
- J Derek Wilson
- Alex Kuang
- Simon Dollé
- Rees Dooley
- Saul Shanabrook
- Daniel Nephin
- Simeon Visser
- Joshua Harlow
- Pierre-Yves Chibon
- Haïkel Guémar
- Thomas Goirand
- James Page
- Josh Marshall
- Dougal Matthews
- Monty Taylor
- Maxym Shalenyi
- Jonathan Herriott
- Job Evers